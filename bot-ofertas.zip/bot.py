"""
Bot de ofertas de hardware -> Discord (via webhook)

Fluxo: coleta preço -> salva no SQLite -> compara com menor preço e mediana
dos últimos 90 dias -> se o desconto for relevante, envia um embed ao Discord
marcando os cargos da categoria.

Modos de execução:
  python bot.py          roda UMA vez e termina (ideal para GitHub Actions)
  python bot.py --loop   roda continuamente (ideal para PC/VPS ligado)

Variáveis de ambiente:
  DISCORD_WEBHOOK_URL   (obrigatória) URL do webhook do canal
  ML_ACCESS_TOKEN       (opcional)    token da API do Mercado Livre
  INTERVALO_MIN         (opcional)    minutos entre coletas (padrão 30)
  DESCONTO_MIN          (opcional)    desconto mínimo vs mediana, ex: 0.10
  MIN_AMOSTRAS          (opcional)    mínimo de registros no histórico (padrão 10)
"""
import json
import logging
import os
import sqlite3
import statistics
import time
from datetime import datetime, timedelta

import requests

WEBHOOK = os.environ.get("DISCORD_WEBHOOK_URL", "")
ML_TOKEN = os.environ.get("ML_ACCESS_TOKEN", "")
INTERVALO_MIN = int(os.environ.get("INTERVALO_MIN", "30"))
DESCONTO_MIN = float(os.environ.get("DESCONTO_MIN", "0.10"))
MIN_AMOSTRAS = int(os.environ.get("MIN_AMOSTRAS", "10"))
JANELA_DIAS = 90
DB_PATH = "ofertas.db"
PRODUTOS_PATH = "produtos.json"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("bot-ofertas")


# ---------------------------------------------------------------- banco
def conectar():
    db = sqlite3.connect(DB_PATH)
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS precos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chave TEXT NOT NULL,
            preco REAL NOT NULL,
            coletado_em TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_precos ON precos (chave, coletado_em);
        CREATE TABLE IF NOT EXISTS alertas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chave TEXT NOT NULL,
            preco REAL NOT NULL,
            enviado_em TEXT NOT NULL
        );
        """
    )
    return db


def agora():
    return datetime.utcnow().isoformat(timespec="seconds")


def historico(db, chave):
    limite = (datetime.utcnow() - timedelta(days=JANELA_DIAS)).isoformat(timespec="seconds")
    rows = db.execute(
        "SELECT preco FROM precos WHERE chave = ? AND coletado_em >= ?", (chave, limite)
    ).fetchall()
    return [r[0] for r in rows]


def alerta_recente(db, chave, preco):
    """True se já avisamos esse produto nas últimas 24h por um preço igual ou menor."""
    limite = (datetime.utcnow() - timedelta(hours=24)).isoformat(timespec="seconds")
    row = db.execute(
        "SELECT 1 FROM alertas WHERE chave = ? AND enviado_em >= ? AND preco <= ? LIMIT 1",
        (chave, limite, preco),
    ).fetchone()
    return row is not None


# ------------------------------------------------------------ coletores
# Cada coletor recebe o item da watchlist e devolve um dict:
# {titulo, loja, preco, url, imagem, disponivel}
def coletar_mercadolivre(item):
    headers = {"Authorization": f"Bearer {ML_TOKEN}"} if ML_TOKEN else {}
    r = requests.get(
        f"https://api.mercadolibre.com/items/{item['id']}", headers=headers, timeout=20
    )
    r.raise_for_status()
    d = r.json()
    imagem = (d.get("pictures") or [{}])[0].get("secure_url") or d.get("thumbnail", "")
    return {
        "titulo": d["title"],
        "loja": "Mercado Livre",
        "preco": float(d["price"]),
        "url": d["permalink"],
        "imagem": imagem,
        "disponivel": d.get("status") == "active" and d.get("available_quantity", 0) > 0,
    }


# Para adicionar outra loja: crie uma função coletar_xxx(item) e registre aqui.
COLETORES = {
    "mercadolivre": coletar_mercadolivre,
}


# -------------------------------------------------------------- discord
def brl(valor):
    return "R$ " + f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def enviar_discord(item, dados, menor, mediana, desconto):
    cargos = item.get("cargos", [])
    mencoes = " ".join(f"<@&{c}>" for c in cargos)
    campos = [
        {"name": "Preço", "value": brl(dados["preco"]), "inline": True},
        {"name": "Menor preço em 90 dias", "value": brl(menor), "inline": True},
        {"name": "Mediana em 90 dias", "value": brl(mediana), "inline": True},
        {"name": "Acessar oferta", "value": dados["url"], "inline": False},
    ]
    if item.get("url_especificacoes"):
        campos.append(
            {"name": "Especificações", "value": item["url_especificacoes"], "inline": False}
        )
    embed = {
        "title": f"{dados['titulo']} [{desconto:.0%} OFF]"[:256],
        "description": dados["loja"],
        "color": 0xE74C3C,
        "fields": campos,
    }
    if dados["imagem"]:
        embed["image"] = {"url": dados["imagem"]}

    payload = {
        "content": mencoes,
        "embeds": [embed],
        "allowed_mentions": {"roles": cargos},
    }
    r = requests.post(WEBHOOK, json=payload, timeout=20)
    if r.status_code == 429:  # rate limit do Discord
        time.sleep(float(r.json().get("retry_after", 2)))
        r = requests.post(WEBHOOK, json=payload, timeout=20)
    r.raise_for_status()


# ---------------------------------------------------------------- ciclo
def processar(db, item):
    coletor = COLETORES.get(item["loja"])
    if not coletor:
        log.warning("Loja sem coletor: %s", item["loja"])
        return

    dados = coletor(item)
    if not dados["disponivel"] or dados["preco"] <= 0:
        log.info("Ignorado (indisponível/preço inválido): %s", dados["titulo"])
        return

    chave = f"{item['loja']}:{item['id']}"
    anteriores = historico(db, chave)  # histórico ANTES de gravar o preço atual
    db.execute(
        "INSERT INTO precos (chave, preco, coletado_em) VALUES (?, ?, ?)",
        (chave, dados["preco"], agora()),
    )
    db.commit()

    if len(anteriores) < MIN_AMOSTRAS:
        log.info("Histórico insuficiente (%d/%d): %s", len(anteriores), MIN_AMOSTRAS, dados["titulo"])
        return

    mediana = statistics.median(anteriores)
    menor = min(anteriores + [dados["preco"]])
    desconto = (mediana - dados["preco"]) / mediana

    log.info("%s | %s | mediana %s | desconto %.1f%%",
             dados["titulo"][:50], brl(dados["preco"]), brl(mediana), desconto * 100)

    if desconto >= DESCONTO_MIN and not alerta_recente(db, chave, dados["preco"]):
        enviar_discord(item, dados, menor, mediana, desconto)
        db.execute(
            "INSERT INTO alertas (chave, preco, enviado_em) VALUES (?, ?, ?)",
            (chave, dados["preco"], agora()),
        )
        db.commit()
        log.info("Alerta enviado: %s", dados["titulo"])


def ciclo(db):
    with open(PRODUTOS_PATH, encoding="utf-8") as f:
        produtos = json.load(f)
    for item in produtos:
        try:
            processar(db, item)
        except Exception as e:  # um produto com erro não derruba os outros
            log.error("Erro em %s: %s", item.get("id"), e)
        time.sleep(2)  # educação com as APIs


def main():
    import sys

    if not WEBHOOK:
        raise SystemExit("Defina DISCORD_WEBHOOK_URL antes de rodar.")
    db = conectar()
    if "--loop" in sys.argv:
        log.info("Modo contínuo. Intervalo: %d min.", INTERVALO_MIN)
        while True:
            ciclo(db)
            time.sleep(INTERVALO_MIN * 60)
    else:
        log.info("Execução única.")
        ciclo(db)


if __name__ == "__main__":
    main()
